package game.com;

import com.badlogic.gdx.graphics.Texture;

class Big_Red_Bird extends Bird {
    public Big_Red_Bird(float x, float y , Texture texture, float height, float width , float health) {
        super(health, texture, x, y, width, height);
    }
}
